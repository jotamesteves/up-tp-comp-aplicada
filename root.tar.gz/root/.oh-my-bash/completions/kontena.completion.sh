#! bash oh-my-bash.module
_omb_util_binary_exists kontena && . "$( kontena whoami --bash-completion-path )"
