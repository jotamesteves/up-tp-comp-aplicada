# rbenv plugin

The rbenv plugin will configure rbenv paths.

## List of aliases

| Alias  | Command          | Description                          |
|--------|------------------|--------------------------------------|
| rubies | 'rbenv versions' | shows all installed versions of ruby |
