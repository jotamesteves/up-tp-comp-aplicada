#! bash oh-my-bash.module

alias cz='chezmoi'
alias cza='chezmoi add'
alias czcd='chezmoi cd'
alias cze='chezmoi edit'
alias czea='chezmoi edit --apply'
alias czra='chezmoi re-add'
