#! bash oh-my-bash.module

alias cg='cargo'
alias cgr='cargo run'
alias cgt='cargo test'
alias cgb='cargo build'
alias cgbr='cargo build --release'
alias cgi='cargo init'
alias cgn='cargo new'
alias cga='cargo add'
alias cgf='cargo fmt'
