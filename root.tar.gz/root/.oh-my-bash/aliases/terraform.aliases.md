# Aliases `terraform`

This defines aliases for `terraform`.

| Alias    | Command                      |
| -------- | ---------------------------- |
| `t`      | `terraform`                  |
| `tinit`  | `terraform init`             |
| `tplan`  | `terraform plan`             |
| `tapply` | `terraform apply`            |
| `tfmt`   | `terraform fmt`              |
