# Aliases
# (sorted alphabetically)
#

alias t='terraform'

alias tapply='terraform apply'
alias tfmt='terraform fmt'
alias tinit='terraform init'
alias tplan='terraform plan'
