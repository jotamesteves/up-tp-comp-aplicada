# 🧙 Powerline-Wizard 🔮

### Powerline-Wizard is a modified version of Powerline-Icon theme for Oh My Bash 🧑‍💻

## 📸 Screenshots
![Screenshot](./powerline-wizard-dark.png?raw=true)
