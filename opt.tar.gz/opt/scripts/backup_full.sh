#!/bin/bash

# Función para mostrar la ayuda
function show_help() {
    echo "Uso: $0 [origen] [destino]"
    echo "Realiza un backup del directorio de origen al directorio de destino."
    echo "  origen: directorio a respaldar"
    echo "  destino: directorio donde se guardará el backup"
    echo "Opciones:"
    echo "  -h      Muestra esta ayuda"
}

# Comprobar si se pasan los argumentos
if [ $# -ne 2 ]; then
    if [[ $1 == "-h" ]]; then
        show_help
        exit 0
    else
        echo "Error: Se requieren dos argumentos."
        show_help
        exit 1
    fi
fi

ORIGEN="$1"
DESTINO="$2"

# Verificar si los directorios existen
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe."
    exit 1
fi

# Obtener la fecha en formato ANSI
FECHA=$(date +%Y%m%d)

# Crear el nombre del archivo de backup
NOMBRE_BKP="$(basename $ORIGEN)_bkp_$FECHA.tar.gz"

# Realizar el backup
tar -czf "$DESTINO/$NOMBRE_BKP" -C "$ORIGEN" .

# Verificar el resultado del backup
if [ $? -eq 0 ]; then
    echo "Backup realizado con éxito: $DESTINO/$NOMBRE_BKP"
else
    echo "Error al realizar el backup."
    exit 1
fi

